    
function Dmat = identify_tangent ( node_c ) 

if (node_c(1)>=0 && node_c(1)<=0.2 && node_c(2)>=0.3 && node_c(2)<=0.4)
        E = 10 ; 
        nu = 0.2; 
        Consti;
else
        E = 100 ; 
        nu = 0.2; 
        Consti;
end